/**
 * ollamaClient.js
 * REST API client for Ollama and OpenAI-compatible endpoints — supports streaming responses, model listing, system prompts.
 */

const OllamaClient = (() => {

  let _baseUrl      = 'http://localhost:11434';
  let _model        = 'llama3';
  let _provider     = 'ollama'; // 'ollama' or 'openai'
  let _apiKey       = '';
  let _systemPrompt = '';

  function configure(baseUrl, model, provider = 'ollama', apiKey = '') {
    if (baseUrl) _baseUrl = baseUrl.replace(/\/$/, '');
    if (model)   _model   = model;
    _provider = provider;
    _apiKey   = apiKey;
  }

  function setSystemPrompt(prompt) {
    _systemPrompt = prompt || '';
  }

  function getSystemPrompt() { return _systemPrompt; }

  /** Quick connectivity check (only really applies to Ollama local) */
  async function ping() {
    if (_provider === 'openai') return true; // Assume cloud is up
    try {
      const res = await fetch(`${_baseUrl}/api/tags`, { signal: AbortSignal.timeout(3000) });
      return res.ok;
    } catch { return false; }
  }

  /** List available local models → [{name, size, modified}] */
  async function listModels() {
    if (_provider === 'openai') return [];
    try {
      const res = await fetch(`${_baseUrl}/api/tags`);
      if (!res.ok) return [];
      const data = await res.json();
      return (data.models || []).map(m => ({
        name:       m.name,
        size:       m.size,
        modified:   m.modified_at,
        paramSize:  m.details?.parameter_size || '',
        family:     m.details?.family || '',
      }));
    } catch { return []; }
  }

  async function runChunk(chunk, priorChunks = [], onToken = () => {}, signal = null) {
    // Build context
    const contextParts = priorChunks.map(c => {
      if (c.type === 'code') return `[Code Block (${c.lang || 'unknown'})]\n\`\`\`${c.lang || ''}\n${c.content}\n\`\`\``;
      if (c.type === 'ai-prompt' && c.output) return `[Previous AI Response]\n${c.output}`;
      if (c.type === 'markdown' && c.content.trim()) return `[Document Context]\n${c.content}`;
      return null;
    }).filter(Boolean);

    let systemParts = [];
    if (_systemPrompt.trim()) {
      systemParts.push(_systemPrompt.trim());
    } else {
      systemParts.push('You are a helpful AI assistant embedded in a Markdown notebook editor.');
    }
    if (contextParts.length) {
      systemParts.push(`\nBelow is the context from previous cells:\n\n${contextParts.join('\n\n---\n\n')}\n\nUse this context to answer the user's prompt that follows.`);
    }
    const systemPrompt = systemParts.join('\n');

    let userPrompt;
    if (chunk.type === 'ai-prompt') {
      userPrompt = chunk.content;
    } else if (chunk.type === 'code') {
      userPrompt = `Here is a ${chunk.lang || 'code'} snippet from my project. Help me with it — analyze, explain, fix issues, or improve it as appropriate:\n\`\`\`${chunk.lang || ''}\n${chunk.content}\n\`\`\``;
    } else {
      // markdown cell
      userPrompt = chunk.content;
    }

    if (_provider === 'openai') {
      return await _runOpenAIStream([{role:'system', content:systemPrompt}, {role:'user', content:userPrompt}], onToken, signal);
    } else {
      return await _runOllamaStream(systemPrompt, userPrompt, onToken, signal);
    }
  }

  async function _runOllamaStream(systemPrompt, userPrompt, onToken, signal) {
    const body = { model: _model, prompt: userPrompt, system: systemPrompt, stream: true };
    const fetchOptions = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
    if (signal) fetchOptions.signal = signal;

    const res = await fetch(`${_baseUrl}/api/generate`, fetchOptions);
    if (!res.ok) throw new Error(`Ollama error ${res.status}: ${await res.text()}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const lines = decoder.decode(value, { stream: true }).split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const json = JSON.parse(line);
          if (json.response) { fullText += json.response; onToken(json.response); }
          if (json.done) return fullText;
        } catch {}
      }
    }
    return fullText;
  }

  async function _runOpenAIStream(messages, onToken, signal) {
    const body = { model: _model, messages, stream: true };
    const headers = { 'Content-Type': 'application/json' };
    if (_apiKey) headers['Authorization'] = `Bearer ${_apiKey}`;
    const fetchOptions = { method: 'POST', headers, body: JSON.stringify(body) };
    if (signal) fetchOptions.signal = signal;

    const res = await fetch(`${_baseUrl}/chat/completions`, fetchOptions);
    if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let fullText = '';
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split('\n');
      buffer = parts.pop() || ''; // keep the last partial piece in buffer

      for (const part of parts) {
        const line = part.trim();
        if (line.startsWith('data: ')) {
          const dataStr = line.slice(6);
          if (dataStr === '[DONE]') break;
          try {
            const data = JSON.parse(dataStr);
            const content = data.choices[0]?.delta?.content;
            if (content) { fullText += content; onToken(content); }
          } catch {}
        }
      }
    }
    return fullText;
  }

  return { configure, setSystemPrompt, getSystemPrompt, ping, listModels, runChunk };
})();
