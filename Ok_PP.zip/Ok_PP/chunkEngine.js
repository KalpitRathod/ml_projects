/**
 * chunkEngine.js
 * Parses .md files into ordered chunks and serializes them back.
 * Chunk boundary delimiter: <!-- chunk:{id}:{type}:{lang} --> ... <!-- /chunk:{id} -->
 */

const ChunkEngine = (() => {

  const CHUNK_OPEN_RE  = /^<!--\s*chunk:([a-z0-9\-]+):([a-z\-]+)(?::([a-z]+))?\s*-->$/;
  const CHUNK_CLOSE_RE = /^<!--\s*\/chunk:([a-z0-9\-]+)\s*-->$/;

  function uuid() {
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    ).slice(0, 8);
  }

  /** Create a fresh empty chunk */
  function createChunk(type = 'markdown', lang = '') {
    return {
      id:        uuid(),
      type,                      // 'markdown' | 'code' | 'ai-prompt'
      lang:      lang || (type === 'code' ? 'javascript' : ''),
      content:   '',
      output:    '',
      collapsed: false,
    };
  }

  /**
   * parseFileToChunks(text) → Chunk[]
   *
   * Strategy:
   *   1. If file has chunk delimiters, parse them directly.
   *   2. Otherwise, auto-split on `---` horizontal rules and `## ` headings.
   *   3. Single-chunk fallback for plain files.
   */
  function parseFileToChunks(text) {
    if (!text || !text.trim()) return [createChunk('markdown')];

    const lines = text.split('\n');

    // ── Strategy 1: Explicit chunk delimiters ──
    const hasDelimiters = lines.some(l => CHUNK_OPEN_RE.test(l.trim()));
    if (hasDelimiters) return parseDelimited(lines);

    // ── Strategy 2: Auto-split heuristics ──
    return parseAutoSplit(lines);
  }

  function parseDelimited(lines) {
    const chunks = [];
    let current  = null;
    let bodyLines= [];

    for (const line of lines) {
      const t = line.trim();
      const openMatch  = t.match(CHUNK_OPEN_RE);
      const closeMatch = t.match(CHUNK_CLOSE_RE);

      if (openMatch) {
        // If there was loose content before first delimiter, wrap it
        if (!current && bodyLines.some(l => l.trim())) {
          chunks.push({ ...createChunk('markdown'), content: bodyLines.join('\n').trim() });
        }
        current = {
          id:      openMatch[1],
          type:    openMatch[2],
          lang:    openMatch[3] || '',
          content: '',
          output:  '',
          collapsed: false,
        };
        bodyLines = [];
      } else if (closeMatch && current && closeMatch[1] === current.id) {
        current.content = bodyLines.join('\n').trim();
        chunks.push(current);
        current   = null;
        bodyLines = [];
      } else {
        bodyLines.push(line);
      }
    }

    // Trailing content
    if (bodyLines.some(l => l.trim())) {
      chunks.push({ ...createChunk('markdown'), content: bodyLines.join('\n').trim() });
    }

    return chunks.length ? chunks : [createChunk('markdown')];
  }

  function parseAutoSplit(lines) {
    const chunks  = [];
    let buffer    = [];
    let chunkType = 'markdown';
    let inFence   = false;
    let fenceLang = '';

    function flush() {
      const content = buffer.join('\n').trim();
      if (content) {
        chunks.push({ ...createChunk(chunkType, fenceLang), content });
      }
      buffer = [];
    }

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      // Track fenced code blocks so we don't split inside them
      if (/^```/.test(trimmed)) {
        if (!inFence) {
          inFence   = true;
          fenceLang = trimmed.replace(/^```/, '').split(/\s/)[0] || '';
          // If we have markdown content above, flush it first
          if (buffer.some(l => l.trim())) {
            flush();
            chunkType = 'code';
          }
        } else {
          buffer.push(line);
          flush();
          inFence   = false;
          fenceLang = '';
          chunkType = 'markdown';
          continue;
        }
      }

      // Split on --- (hr) outside fences
      if (!inFence && trimmed === '---' && buffer.some(l => l.trim())) {
        flush();
        chunkType = 'markdown';
        continue;
      }

      // Split on ## headings (h2+) outside fences, starting a new chunk
      if (!inFence && /^#{2,}\s+/.test(trimmed) && buffer.some(l => l.trim())) {
        flush();
        chunkType = 'markdown';
      }

      buffer.push(line);
    }
    flush();

    // Re-detect chunk types after parsing
    chunks.forEach(c => {
      if (c.type === 'markdown' && /^```/.test(c.content)) c.type = 'code';
    });

    return chunks.length ? chunks : [createChunk('markdown')];
  }

  /**
   * chunksToFile(chunks) → string
   * Serializes chunks back to a .md file with delimiters.
   */
  function chunksToFile(chunks) {
    return chunks.map(c => {
      const header = `<!-- chunk:${c.id}:${c.type}${c.lang ? ':' + c.lang : ''} -->`;
      const footer = `<!-- /chunk:${c.id} -->`;
      const parts  = [header, c.content];
      if (c.output && c.output.trim()) {
        parts.push('');
        parts.push(`<!-- output:${c.id} -->`);
        parts.push(c.output.trim());
        parts.push(`<!-- /output:${c.id} -->`);
      }
      parts.push(footer);
      return parts.join('\n');
    }).join('\n\n');
  }

  /**
   * chunksToCleanFile(chunks) → string
   * Exports without any delimiter comments — clean human-readable .md.
   * Includes AI output appended after prompt/code content.
   */
  function chunksToCleanFile(chunks) {
    return chunks.map(c => {
      const parts = [];
      if (c.type === 'code') {
        parts.push(`\`\`\`${c.lang || ''}\n${c.content}\n\`\`\``);
      } else {
        if (c.content) parts.push(c.content);
      }
      // Include AI/run output in the file
      if (c.output && c.output.trim()) {
        parts.push(c.output.trim());
      }
      return parts.join('\n\n');
    }).filter(Boolean).join('\n\n');
  }

  /** Insert a new chunk after the chunk with given id */
  function insertChunkAfter(chunks, afterId, type, lang) {
    const newChunk = createChunk(type, lang);
    const idx      = chunks.findIndex(c => c.id === afterId);
    const result   = [...chunks];
    result.splice(idx + 1, 0, newChunk);
    return { chunks: result, newId: newChunk.id };
  }

  /** Insert a new chunk at the front */
  function insertChunkFirst(chunks, type, lang) {
    const newChunk = createChunk(type, lang);
    return { chunks: [newChunk, ...chunks], newId: newChunk.id };
  }

  /** Remove a chunk by id */
  function removeChunk(chunks, id) {
    return chunks.filter(c => c.id !== id);
  }

  /** Move chunk up or down */
  function moveChunk(chunks, id, direction) {
    const arr = [...chunks];
    const idx = arr.findIndex(c => c.id === id);
    if (idx < 0) return arr;
    if (direction === 'up'   && idx === 0)             return arr;
    if (direction === 'down' && idx === arr.length - 1) return arr;
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    [arr[idx], arr[swapIdx]] = [arr[swapIdx], arr[idx]];
    return arr;
  }

  /** Duplicate a chunk */
  function duplicateChunk(chunks, id) {
    const arr = [...chunks];
    const idx = arr.findIndex(c => c.id === id);
    if (idx < 0) return arr;
    const dup = { ...arr[idx], id: uuid(), output: '' };
    arr.splice(idx + 1, 0, dup);
    return arr;
  }

  /** Update chunk content */
  function updateChunk(chunks, id, patch) {
    return chunks.map(c => c.id === id ? { ...c, ...patch } : c);
  }

  /** Re-parse the raw file string into chunks (for Raw preview edits) */
  function reconcileFromRaw(rawText, existingChunks) {
    // Try: if the raw text has chunk delimiters, parse them properly
    const parsed = parseFileToChunks(rawText);
    // Preserve outputs for chunks whose id matches
    const outputMap = {};
    existingChunks.forEach(c => { outputMap[c.id] = c.output; });
    parsed.forEach(c => {
      if (outputMap[c.id]) c.output = outputMap[c.id];
    });
    return parsed;
  }

  return {
    createChunk,
    parseFileToChunks,
    chunksToFile,
    chunksToCleanFile,
    insertChunkAfter,
    insertChunkFirst,
    removeChunk,
    moveChunk,
    duplicateChunk,
    updateChunk,
    reconcileFromRaw,
    uuid,
  };

})();
