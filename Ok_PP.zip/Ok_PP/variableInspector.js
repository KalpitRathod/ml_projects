/**
 * variableInspector.js
 * Parses code chunks to extract variables, functions, and classes.
 * Supports JavaScript, TypeScript, Python, Bash basics.
 */

const VariableInspector = (() => {

  // ── JS / TS patterns ──
  const JS_PATTERNS = [
    // const/let/var declarations
    { re: /^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*(?:=|;)/gm, group: 1, kind: 'variable' },
    // function declarations
    { re: /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(/gm, group: 1, kind: 'function' },
    // arrow + const
    { re: /^\s*(?:export\s+)?(?:const|let)\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/gm, group: 1, kind: 'function' },
    // class declarations
    { re: /^\s*(?:export\s+)?class\s+([A-Za-z_$][A-Za-z0-9_$]*)/gm, group: 1, kind: 'class' },
    // destructuring (basic)
    { re: /^\s*(?:const|let|var)\s+\{([^}]+)\}\s*=/gm, group: 1, kind: 'destructure' },
  ];

  // ── Python patterns ──
  const PY_PATTERNS = [
    { re: /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/gm,              group: 1, kind: 'variable' },
    { re: /^\s*def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/gm,        group: 1, kind: 'function' },
    { re: /^\s*async\s+def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/gm,group: 1, kind: 'function' },
    { re: /^\s*class\s+([A-Za-z_][A-Za-z0-9_]*)/gm,            group: 1, kind: 'class' },
  ];

  // ── Bash patterns ──
  const BASH_PATTERNS = [
    { re: /^\s*([A-Za-z_][A-Za-z0-9_]*)=[^=]/gm,   group: 1, kind: 'variable' },
    { re: /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(\)\s*\{/gm, group: 1, kind: 'function' },
  ];

  const LANG_MAP = {
    javascript: JS_PATTERNS,
    js:         JS_PATTERNS,
    typescript: JS_PATTERNS,
    ts:         JS_PATTERNS,
    python:     PY_PATTERNS,
    py:         PY_PATTERNS,
    bash:       BASH_PATTERNS,
    sh:         BASH_PATTERNS,
  };

  /** Extract names from a destructuring group like "a, b, c" */
  function expandDestructure(str) {
    return str.split(',').map(s => s.trim().split(':')[0].trim()).filter(Boolean);
  }

  /**
   * analyzeChunk(chunk) → { variables: [], functions: [], classes: [] }
   */
  function analyzeChunk(chunk) {
    const result = { variables: new Set(), functions: new Set(), classes: new Set() };
    if (chunk.type === 'markdown' || chunk.type === 'ai-prompt') return result;

    const patterns = LANG_MAP[chunk.lang] || JS_PATTERNS;
    const code = chunk.content;

    for (const { re, group, kind } of patterns) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(code)) !== null) {
        const raw = m[group] || '';
        if (kind === 'destructure') {
          expandDestructure(raw).forEach(name => result.variables.add(name));
        } else if (kind === 'function' || kind === 'class') {
          result[kind === 'class' ? 'classes' : 'functions'].add(raw.trim());
        } else {
          result.variables.add(raw.trim());
        }
      }
    }

    // Remove names that are actually functions
    result.functions.forEach(name => result.variables.delete(name));
    result.classes.forEach(name => result.variables.delete(name));

    return result;
  }

  /**
   * analyzeAll(chunks) → { globals, functions, variables, byChunk }
   *
   * globals   — items defined in chunks 0..N-1 (available to all later chunks)
   * functions — collected across all code chunks
   * variables — all non-function variables
   * byChunk   — map of chunkId → { variables, functions, classes }
   */
  function analyzeAll(chunks) {
    const globals   = new Map(); // name → chunkIndex
    const functions = new Map();
    const variables = new Map();
    const classes   = new Map();
    const byChunk   = {};

    chunks.forEach((chunk, idx) => {
      const found = analyzeChunk(chunk);
      byChunk[chunk.id] = found;

      found.functions.forEach(name => {
        functions.set(name, idx);
        globals.set(name, idx);
      });
      found.classes.forEach(name => {
        classes.set(name, idx);
        globals.set(name, idx);
      });
      found.variables.forEach(name => {
        if (!functions.has(name) && !classes.has(name)) {
          variables.set(name, idx);
          globals.set(name, idx);
        }
      });
    });

    return {
      globals:   [...globals.entries()].map(([name, idx]) => ({ name, chunkIdx: idx })),
      functions: [...functions.entries()].map(([name, idx]) => ({ name, chunkIdx: idx })),
      variables: [...variables.entries()].map(([name, idx]) => ({ name, chunkIdx: idx })),
      classes:   [...classes.entries()].map(([name, idx]) => ({ name, chunkIdx: idx })),
      byChunk,
    };
  }

  return { analyzeChunk, analyzeAll };
})();
