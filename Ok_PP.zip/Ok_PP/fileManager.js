/**
 * fileManager.js
 * File System Access API wrapper — full file management: open, read, write,
 * copy, move, delete, rename, create folder, list all files, download.
 */

const FileManager = (() => {

  let _dirHandle  = null;
  let _fileHandle = null;

  /** Open a directory via picker */
  async function openFolder() {
    try {
      const dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
      _dirHandle = dirHandle;
      const entries = await listAllFiles(dirHandle, '');
      return { dirHandle, entries };
    } catch (err) {
      if (err.name === 'AbortError') return null;
      throw err;
    }
  }

  /**
   * Recursively list ALL files from a directory handle.
   * Returns: [{ name, path, handle, dirHandle, isDir, children, size, lastModified }]
   */
  async function listAllFiles(dirHandle, basePath) {
    const results = [];
    for await (const [name, handle] of dirHandle.entries()) {
      const fullPath = basePath ? `${basePath}/${name}` : name;
      if (handle.kind === 'file') {
        let size = 0, lastModified = 0;
        try {
          const file = await handle.getFile();
          size = file.size;
          lastModified = file.lastModified;
        } catch {}
        results.push({ name, path: fullPath, handle, dirHandle, isDir: false, size, lastModified });
      } else if (handle.kind === 'directory') {
        const children = await listAllFiles(handle, fullPath);
        results.push({ name, path: fullPath, handle, dirHandle, isDir: true, children });
      }
    }
    // Sort: directories first, then files alphabetically
    results.sort((a, b) => {
      if (a.isDir && !b.isDir) return -1;
      if (!a.isDir && b.isDir) return 1;
      return a.name.localeCompare(b.name);
    });
    return results;
  }

  /** List only .md files (for backward compat) */
  async function listMdFiles(dirHandle, basePath) {
    const all = await listAllFiles(dirHandle, basePath);
    return filterMd(all);
  }

  function filterMd(entries) {
    return entries.filter(e => {
      if (e.isDir) {
        e.children = filterMd(e.children || []);
        return e.children.length > 0;
      }
      return e.name.toLowerCase().endsWith('.md');
    });
  }

  /** Read a file entry → text content */
  async function readFile(fileEntry) {
    _fileHandle = fileEntry.handle;
    const file = await fileEntry.handle.getFile();
    return await file.text();
  }

  /** Read by handle directly */
  async function readHandle(handle) {
    _fileHandle = handle;
    const file = await handle.getFile();
    return await file.text();
  }

  /** Write text to the current file handle */
  async function writeCurrentFile(text) {
    if (!_fileHandle) throw new Error('No file is currently open');
    await writeHandle(_fileHandle, text);
  }

  /** Write text to any file handle */
  async function writeHandle(handle, text) {
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
  }

  /** Create a new file in the current directory */
  async function createNewFile(filename, parentHandle = null) {
    const dir = parentHandle || _dirHandle;
    if (!dir) throw new Error('No folder is open');
    const handle = await dir.getFileHandle(filename, { create: true });
    await writeHandle(handle, `# ${filename.replace('.md', '')}\n\n`);
    _fileHandle = handle;
    return { name: filename, path: filename, handle, dirHandle: dir, isDir: false };
  }

  /** Create a new folder */
  async function createFolder(folderName, parentHandle = null) {
    const dir = parentHandle || _dirHandle;
    if (!dir) throw new Error('No folder is open');
    const handle = await dir.getDirectoryHandle(folderName, { create: true });
    return { name: folderName, path: folderName, handle, dirHandle: dir, isDir: true, children: [] };
  }

  /** Delete a file */
  async function deleteFile(parentDirHandle, fileName) {
    await parentDirHandle.removeEntry(fileName);
  }

  /** Delete a folder (recursive) */
  async function deleteFolder(parentDirHandle, folderName) {
    await parentDirHandle.removeEntry(folderName, { recursive: true });
  }

  /** Copy a file to a destination directory */
  async function copyFile(srcFileEntry, destDirHandle) {
    const srcFile = await srcFileEntry.handle.getFile();
    const content = await srcFile.text();
    const newHandle = await destDirHandle.getFileHandle(srcFileEntry.name, { create: true });
    await writeHandle(newHandle, content);
    return { name: srcFileEntry.name, handle: newHandle, dirHandle: destDirHandle };
  }

  /** Move a file to a destination directory (copy + delete original) */
  async function moveFile(srcFileEntry, destDirHandle) {
    const copied = await copyFile(srcFileEntry, destDirHandle);
    await srcFileEntry.dirHandle.removeEntry(srcFileEntry.name);
    return copied;
  }

  /** Duplicate a file in the same directory */
  async function duplicateFile(srcFileEntry) {
    const srcFile = await srcFileEntry.handle.getFile();
    const content = await srcFile.text();
    const baseName = srcFileEntry.name.replace(/\.[^.]+$/, '');
    const ext      = srcFileEntry.name.slice(baseName.length);
    const newName  = `${baseName} (copy)${ext}`;
    const newHandle = await srcFileEntry.dirHandle.getFileHandle(newName, { create: true });
    await writeHandle(newHandle, content);
    return { name: newName, handle: newHandle, dirHandle: srcFileEntry.dirHandle };
  }

  /** Rename a file (copy with new name + delete old) */
  async function renameFile(srcFileEntry, newName) {
    const srcFile = await srcFileEntry.handle.getFile();
    const content = await srcFile.text();
    const newHandle = await srcFileEntry.dirHandle.getFileHandle(newName, { create: true });
    await writeHandle(newHandle, content);
    await srcFileEntry.dirHandle.removeEntry(srcFileEntry.name);
    return { name: newName, handle: newHandle, dirHandle: srcFileEntry.dirHandle };
  }

  /** Rename a folder recursively */
  async function renameFolder(srcDirEntry, newName) {
    const parentHandle = srcDirEntry.dirHandle;
    const newDirHandle = await parentHandle.getDirectoryHandle(newName, { create: true });
    await _copyFolderRecursive(srcDirEntry.handle, newDirHandle);
    await parentHandle.removeEntry(srcDirEntry.name, { recursive: true });
    return { name: newName, path: newName, handle: newDirHandle, dirHandle: parentHandle, isDir: true };
  }

  async function _copyFolderRecursive(srcHandle, destHandle) {
    for await (const [name, handle] of srcHandle.entries()) {
      if (handle.kind === 'file') {
        const file = await handle.getFile();
        const buffer = await file.arrayBuffer();
        const newFileHandle = await destHandle.getFileHandle(name, { create: true });
        const writable = await newFileHandle.createWritable();
        await writable.write(buffer);
        await writable.close();
      } else if (handle.kind === 'directory') {
        const newSubDir = await destHandle.getDirectoryHandle(name, { create: true });
        await _copyFolderRecursive(handle, newSubDir);
      }
    }
  }

  /** Download a file to the user's computer */
  async function downloadFile(fileEntry) {
    const file = await fileEntry.handle.getFile();
    const url  = URL.createObjectURL(file);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = fileEntry.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /** Refresh the file tree for the current directory */
  async function refreshTree() {
    if (!_dirHandle) return null;
    return listAllFiles(_dirHandle, '');
  }

  /** Format file size */
  function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  /** Format date */
  function formatDate(timestamp) {
    if (!timestamp) return '—';
    const d = new Date(timestamp);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: '2-digit' });
  }

  function getCurrentHandle() { return _fileHandle; }
  function getDirHandle()     { return _dirHandle; }

  return {
    openFolder, listAllFiles, listMdFiles, readFile, readHandle,
    writeCurrentFile, writeHandle, createNewFile, createFolder,
    deleteFile, deleteFolder, copyFile, moveFile, duplicateFile,
    renameFile, renameFolder, downloadFile, refreshTree, formatSize, formatDate,
    getCurrentHandle, getDirHandle
  };
})();
