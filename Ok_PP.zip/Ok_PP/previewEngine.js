/**
 * previewEngine.js
 * Combines chunks into a full markdown string and renders it.
 * Uses marked.js + highlight.js (loaded from CDN in index.html).
 */

const PreviewEngine = (() => {

  // Configure marked
  function _initMarked() {
    if (typeof marked === 'undefined') return;
    marked.setOptions({
      breaks:   true,
      gfm:      true,
      highlight: (code, lang) => {
        if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
          return hljs.highlight(code, { language: lang }).value;
        }
        return typeof hljs !== 'undefined' ? hljs.highlightAuto(code).value : code;
      },
    });
  }

  /**
   * buildMarkdown(chunks) → string
   * Combines all chunks' content into a clean markdown string for preview.
   * AI outputs are included after their prompts in blockquotes.
   */
  function buildMarkdown(chunks) {
    return chunks.map(c => {
      let parts = [];

      if (c.type === 'markdown') {
        parts.push(c.content || '');
      } else if (c.type === 'code') {
        parts.push(`\`\`\`${c.lang || ''}\n${c.content}\n\`\`\``);
      } else if (c.type === 'ai-prompt') {
        if (c.content) parts.push(`> **AI Prompt:** ${c.content}`);
        if (c.output)  parts.push(`\n${c.output}`);
      }

      return parts.filter(Boolean).join('\n');
    }).filter(Boolean).join('\n\n');
  }

  /**
   * renderToHtml(markdown) → html string
   */
  function renderToHtml(markdown) {
    _initMarked();
    if (typeof marked === 'undefined') {
      return `<pre>${escapeHtml(markdown)}</pre>`;
    }
    try {
      return marked.parse(markdown);
    } catch (e) {
      return `<pre>${escapeHtml(markdown)}</pre>`;
    }
  }

  function escapeHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  /**
   * updatePreview(chunks, htmlEl, textareaEl)
   * Renders chunks into the HTML preview element and updates the raw textarea.
   */
  function updatePreview(chunks, htmlEl, textareaEl) {
    const md   = buildMarkdown(chunks);
    const html = renderToHtml(md);
    if (htmlEl)      htmlEl.innerHTML = html;
    if (textareaEl)  textareaEl.value = md;

    // Apply highlight.js to any code blocks without highlighting
    if (typeof hljs !== 'undefined' && htmlEl) {
      htmlEl.querySelectorAll('pre code:not(.hljs)').forEach(el => {
        hljs.highlightElement(el);
      });
    }
  }

  /**
   * updatePreviewFromRaw(rawMarkdown, htmlEl)
   * Re-renders a raw markdown string into the HTML preview.
   */
  function updatePreviewFromRaw(rawMarkdown, htmlEl) {
    if (!htmlEl) return;
    htmlEl.innerHTML = renderToHtml(rawMarkdown);
    if (typeof hljs !== 'undefined') {
      htmlEl.querySelectorAll('pre code:not(.hljs)').forEach(el => hljs.highlightElement(el));
    }
  }

  return { buildMarkdown, renderToHtml, updatePreview, updatePreviewFromRaw };
})();
