/**
 * app.js — Main controller. Wires all modules, UI events, keyboard shortcuts.
 */

// ── State ──
const State = {
  chunks: [], currentFile: null, fileTree: [], modified: false,
  runController: null, fileViewMode: 'list', selectedFiles: [],
  _focusedChunkId: null,
};

// ── DOM refs ──
const $ = id => document.getElementById(id);
const DOM = {
  toolbar: $('toolbar'), btnOpenFolder: $('btn-open-folder'),
  btnOpenFolderC: $('btn-open-folder-center'),
  btnNewFile: $('btn-new-file'), btnNewFolder: $('btn-new-folder'),
  btnSave: $('btn-save'), currentFilename: $('current-filename'),
  saveStatus: $('save-status'),
  aiProvider: $('ai-provider'),
  ollamaModelSelect: $('ollama-model-select'), openaiModelInput: $('openai-model-input'),
  btnRefreshModels: $('btn-refresh-models'),
  ollamaEndpoint: $('ollama-endpoint'), ollamaStatus: $('ollama-status'),
  indicatorDot: $('ollama-status').querySelector('.indicator-dot'),
  indicatorStatusLabel: $('indicator-status-label'),
  btnAiSettings: $('btn-ai-settings'),
  aiDrawer: $('ai-settings-drawer'), btnCloseDrawer: $('btn-close-drawer'),
  drawerApiKeyField: $('drawer-api-key-field'), apiKeyInput: $('api-key-input'),
  promptPreset: $('prompt-preset'), systemPromptInput: $('system-prompt-input'),
  btnSavePrompt: $('btn-save-prompt'), btnResetPrompt: $('btn-reset-prompt'),
  fileSearchInput: $('file-search-input'), fileTree: $('file-tree'),
  btnRefreshTree: $('btn-refresh-tree'),
  inspectorGlobals: $('inspector-globals'), inspectorFunctions: $('inspector-functions'),
  inspectorVars: $('inspector-variables'),
  chunksContainer: $('chunks-container'), emptyNotebook: $('empty-notebook'),
  btnAddChunkTop: $('btn-add-chunk-top'), btnRunAll: $('btn-run-all'),
  btnCollapseAll: $('btn-collapse-all'), btnExpandAll: $('btn-expand-all'),
  previewHtml: $('preview-html'), previewTextarea: $('preview-textarea'),
  previewTabs: document.querySelectorAll('.preview-tab'),
  previewRendered: $('preview-rendered'), previewRaw: $('preview-raw'),
  btnApplyRaw: $('btn-apply-raw'),
  modalChunkType: $('modal-chunk-type'), modalLangSelector: $('modal-lang-selector'),
  modalLangSelect: $('modal-lang-select'), modalCancel: $('modal-cancel'),
  modalConfirm: $('modal-confirm'),
  modalDeleteConfirm: $('modal-delete-confirm'), deleteConfirmMsg: $('delete-confirm-msg'),
  deleteCancel: $('delete-cancel'), deleteConfirm: $('delete-confirm'),
  modalRename: $('modal-rename'), renameInput: $('rename-input'),
  renameCancel: $('rename-cancel'), renameConfirm: $('rename-confirm'),
  contextMenu: $('context-menu'), fileContextMenu: $('file-context-menu'),
  toastContainer: $('toast-container'),
  fmtHeading: $('fmt-heading'), fmtFont: $('fmt-font'), fmtFontSize: $('fmt-font-size'),
  frPanel: $('find-replace-panel'), frFindInput: $('fr-find-input'),
  frReplaceInput: $('fr-replace-input'), frMatchCount: $('fr-match-count'),
  frPrev: $('fr-prev'), frNext: $('fr-next'),
  frReplaceOne: $('fr-replace-one'), frReplaceAll: $('fr-replace-all'), frClose: $('fr-close'),
};

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

// ── Toast ──
function toast(msg, type = 'info') {
  const el = document.createElement('div'); el.className = `toast ${type}`;
  const icons = { success:'✓', error:'✗', info:'ℹ', warn:'⚠' };
  el.innerHTML = `<span>${icons[type]||''}</span> ${msg}`;
  DOM.toastContainer.appendChild(el);
  setTimeout(() => { el.classList.add('fade-out'); setTimeout(() => el.remove(), 320); }, 2800);
}

// ═══════ OLLAMA STATUS & MODEL DROPDOWN ═══════
async function checkOllamaStatus() {
  OllamaClient.configure(DOM.ollamaEndpoint.value.trim(), DOM.ollamaModelSelect.value || '');
  const online = await OllamaClient.ping();
  DOM.indicatorDot.className = `indicator-dot ${online ? 'online' : 'offline'}`;
  DOM.indicatorStatusLabel.textContent = DOM.aiProvider.value === 'openai' ? 'Cloud' : 'Local';
  if (online && DOM.aiProvider.value === 'ollama') await populateModels();
}

async function populateModels() {
  const models = await OllamaClient.listModels();
  const sel = DOM.ollamaModelSelect;
  const prev = sel.value;
  sel.innerHTML = '';
  if (!models.length) { sel.innerHTML = '<option value="">No models</option>'; return; }
  models.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.name; opt.textContent = `${m.name} ${m.paramSize ? '(' + m.paramSize + ')' : ''}`;
    sel.appendChild(opt);
  });
  // Restore previous or use saved
  const saved = localStorage.getItem('ollama-model');
  if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
  else if (saved && [...sel.options].some(o => o.value === saved)) sel.value = saved;
  updateAiClient();
}

function updateAiClient() {
  const provider = DOM.aiProvider.value;
  const model = provider === 'openai' ? DOM.openaiModelInput.value : DOM.ollamaModelSelect.value;
  const endpoint = DOM.ollamaEndpoint.value.trim() || (provider === 'openai' ? 'https://api.openai.com/v1' : 'http://localhost:11434');
  OllamaClient.configure(endpoint, model, provider, DOM.apiKeyInput.value.trim());
}

DOM.aiProvider.addEventListener('change', () => {
  const isOai = DOM.aiProvider.value === 'openai';
  DOM.ollamaModelSelect.classList.toggle('hidden', isOai);
  DOM.btnRefreshModels.classList.toggle('hidden', isOai);
  DOM.openaiModelInput.classList.toggle('hidden', !isOai);
  DOM.drawerApiKeyField.style.display = isOai ? 'block' : 'none';
  if (isOai && DOM.ollamaEndpoint.value === 'http://localhost:11434') {
    DOM.ollamaEndpoint.value = 'https://api.openai.com/v1';
  } else if (!isOai && DOM.ollamaEndpoint.value === 'https://api.openai.com/v1') {
    DOM.ollamaEndpoint.value = 'http://localhost:11434';
  }
  localStorage.setItem('ai-provider', DOM.aiProvider.value);
  updateAiClient();
  checkOllamaStatus();
});

DOM.openaiModelInput.addEventListener('change', () => {
  localStorage.setItem('openai-model', DOM.openaiModelInput.value);
  updateAiClient();
});
DOM.apiKeyInput.addEventListener('change', () => {
  localStorage.setItem('api-key', DOM.apiKeyInput.value);
  updateAiClient();
});

// Restore saved settings
DOM.aiProvider.value = localStorage.getItem('ai-provider') || 'ollama';
if (DOM.aiProvider.value === 'openai') {
  DOM.drawerApiKeyField.style.display = 'block';
  DOM.ollamaModelSelect.classList.add('hidden');
  DOM.btnRefreshModels.classList.add('hidden');
  DOM.openaiModelInput.classList.remove('hidden');
}
DOM.openaiModelInput.value = localStorage.getItem('openai-model') || 'gpt-4o-mini';
DOM.apiKeyInput.value = localStorage.getItem('api-key') || '';
if (localStorage.getItem('ollama-endpoint')) DOM.ollamaEndpoint.value = localStorage.getItem('ollama-endpoint');

checkOllamaStatus();
setInterval(checkOllamaStatus, 20000);
DOM.ollamaEndpoint.addEventListener('change', () => { localStorage.setItem('ollama-endpoint', DOM.ollamaEndpoint.value); checkOllamaStatus(); });
DOM.ollamaModelSelect.addEventListener('change', () => {
  localStorage.setItem('ollama-model', DOM.ollamaModelSelect.value);
  updateAiClient();
});
DOM.btnRefreshModels.addEventListener('click', () => { populateModels(); toast('Models refreshed', 'info'); });

// ═══════ AI SETTINGS DRAWER ═══════
DOM.btnAiSettings.addEventListener('click', () => DOM.aiDrawer.classList.toggle('hidden'));
DOM.btnCloseDrawer.addEventListener('click', () => DOM.aiDrawer.classList.add('hidden'));

// Load saved prompt
const savedPrompt = localStorage.getItem('system-prompt') || '';
const savedPreset = localStorage.getItem('prompt-preset') || 'general';
DOM.systemPromptInput.value = savedPrompt || PromptPresets[savedPreset] || PromptPresets.general;
DOM.promptPreset.value = savedPreset;
OllamaClient.setSystemPrompt(DOM.systemPromptInput.value);

DOM.promptPreset.addEventListener('change', () => {
  const key = DOM.promptPreset.value;
  if (key !== 'custom' && PromptPresets[key]) {
    DOM.systemPromptInput.value = PromptPresets[key];
    OllamaClient.setSystemPrompt(PromptPresets[key]);
  }
});
DOM.systemPromptInput.addEventListener('input', () => {
  OllamaClient.setSystemPrompt(DOM.systemPromptInput.value);
  DOM.promptPreset.value = 'custom';
});
DOM.btnSavePrompt.addEventListener('click', () => {
  localStorage.setItem('system-prompt', DOM.systemPromptInput.value);
  localStorage.setItem('prompt-preset', DOM.promptPreset.value);
  toast('System prompt saved', 'success');
});
DOM.btnResetPrompt.addEventListener('click', () => {
  DOM.promptPreset.value = 'general';
  DOM.systemPromptInput.value = PromptPresets.general;
  OllamaClient.setSystemPrompt(PromptPresets.general);
  toast('Prompt reset to default', 'info');
});

// ═══════ FORMATTING TOOLBAR ═══════
// Prevent toolbar buttons from stealing focus from the editor
document.getElementById('format-toolbar').addEventListener('mousedown', e => {
  // Don't steal focus from editor textareas (except for selects which need focus)
  if (e.target.tagName !== 'SELECT' && e.target.tagName !== 'OPTION') {
    e.preventDefault();
  }
});

document.querySelectorAll('.fmt-btn[data-cmd]').forEach(btn => {
  btn.addEventListener('click', () => {
    const cmd = btn.dataset.cmd;
    if (cmd === 'undo') { doUndo(); return; }
    if (cmd === 'redo') { doRedo(); return; }
    if (cmd === 'find-replace') { DOM.frPanel.classList.toggle('hidden'); DOM.frFindInput.focus(); return; }
    Formatting.exec(cmd);
  });
});

DOM.fmtHeading.addEventListener('change', () => {
  const level = DOM.fmtHeading.value;
  if (!level) return;
  const n = parseInt(level.replace('h',''));
  Formatting.insertAtCursor('\n' + '#'.repeat(n) + ' ');
  DOM.fmtHeading.value = '';
});

// ═══════ FIND & REPLACE ═══════
DOM.frFindInput.addEventListener('input', () => {
  const res = FindReplace.find(DOM.frFindInput.value);
  DOM.frMatchCount.textContent = `${res.current} / ${res.total}`;
});
DOM.frNext.addEventListener('click', () => {
  const r = FindReplace.next(); if (r) DOM.frMatchCount.textContent = `${r.current} / ${r.total}`;
});
DOM.frPrev.addEventListener('click', () => {
  const r = FindReplace.prev(); if (r) DOM.frMatchCount.textContent = `${r.current} / ${r.total}`;
});
DOM.frReplaceOne.addEventListener('click', () => {
  FindReplace.replaceCurrent(DOM.frReplaceInput.value);
  const r = FindReplace.find(DOM.frFindInput.value);
  DOM.frMatchCount.textContent = `${r.current} / ${r.total}`;
});
DOM.frReplaceAll.addEventListener('click', () => {
  const n = FindReplace.replaceAll(DOM.frFindInput.value, DOM.frReplaceInput.value);
  DOM.frMatchCount.textContent = '0 / 0';
  toast(`Replaced ${n} occurrences`, 'success');
});
DOM.frClose.addEventListener('click', () => DOM.frPanel.classList.add('hidden'));

// ═══════ UNDO/REDO ═══════
function doUndo() {
  if (!State._focusedChunkId) return;
  const chunk = State.chunks.find(c => c.id === State._focusedChunkId);
  if (!chunk) return;
  const prev = UndoManager.undo(chunk.id, chunk.content);
  if (prev !== null) {
    State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, { content: prev });
    const ed = document.querySelector(`.chunk-cell[data-id="${chunk.id}"] .chunk-editor`);
    if (ed) { ed.value = prev; ed.dispatchEvent(new Event('input', { bubbles: true })); }
  }
}
function doRedo() {
  if (!State._focusedChunkId) return;
  const chunk = State.chunks.find(c => c.id === State._focusedChunkId);
  if (!chunk) return;
  const next = UndoManager.redo(chunk.id, chunk.content);
  if (next !== null) {
    State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, { content: next });
    const ed = document.querySelector(`.chunk-cell[data-id="${chunk.id}"] .chunk-editor`);
    if (ed) { ed.value = next; ed.dispatchEvent(new Event('input', { bubbles: true })); }
  }
}

// ═══════ PREVIEW TABS ═══════
DOM.previewTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    DOM.previewTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const target = tab.dataset.tab;
    DOM.previewRendered.classList.toggle('active', target === 'rendered');
    DOM.previewRaw.classList.toggle('active', target === 'raw');
    if (target === 'raw') DOM.previewTextarea.value = PreviewEngine.buildMarkdown(State.chunks);
  });
});
DOM.btnApplyRaw.addEventListener('click', () => {
  State.chunks = ChunkEngine.reconcileFromRaw(DOM.previewTextarea.value, State.chunks);
  renderAllChunks(); markModified(); toast('Applied', 'success');
});

// Collapsible left panel sections
document.querySelectorAll('.section-header.collapsible').forEach(h => {
  h.addEventListener('click', () => {
    const body = document.getElementById(h.dataset.target);
    const arrow = h.querySelector('.collapse-arrow');
    if (body) { body.classList.toggle('hidden'); arrow?.classList.toggle('collapsed', body.classList.contains('hidden')); }
  });
});

// ═══════ FILE VIEW SWITCHER ═══════
document.querySelectorAll('.view-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    State.fileViewMode = btn.dataset.view;
    DOM.fileTree.setAttribute('data-view', btn.dataset.view);
  });
});

// ═══════ FILE SEARCH ═══════
DOM.fileSearchInput.addEventListener('input', () => {
  const q = DOM.fileSearchInput.value.toLowerCase();
  DOM.fileTree.querySelectorAll('.file-tree-file').forEach(el => {
    const name = (el.dataset.name || el.textContent).toLowerCase();
    el.style.display = !q || name.includes(q) ? '' : 'none';
  });
});

// ═══════ FILE TREE ═══════
function renderFileTree(entries, container) {
  container.innerHTML = '';
  if (!entries?.length) { container.innerHTML = '<p class="empty-hint">No files found</p>'; return; }
  renderTreeNodes(entries, container, 0);
}
function renderTreeNodes(entries, container, depth) {
  entries.forEach(e => {
    if (e.isDir) {
      const f = document.createElement('div');
      f.className = 'file-tree-folder'; f.style.paddingLeft = `${8+depth*14}px`;
      f.innerHTML = `<span class="folder-arrow">▶</span> 📁 ${e.name}`;
      container.appendChild(f);
      const cc = document.createElement('div'); cc.style.display = 'none';
      container.appendChild(cc);
      f.addEventListener('click', () => {
        const open = cc.style.display === 'block'; cc.style.display = open ? 'none' : 'block';
        f.querySelector('.folder-arrow').style.transform = open ? '' : 'rotate(90deg)';
      });
      f.addEventListener('contextmenu', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        showFileContextMenu(ev, e);
      });
      if (e.children) renderTreeNodes(e.children, cc, depth + 1);
    } else {
      const el = document.createElement('div');
      el.className = 'file-tree-file'; el.style.paddingLeft = `${8+depth*14}px`;
      el.dataset.path = e.path; el.dataset.name = e.name;
      const icon = e.name.endsWith('.md') ? '📄' : '📎';
      if (State.fileViewMode === 'details') {
        el.innerHTML = `${icon} <span>${e.name}</span><span class="file-detail">${FileManager.formatSize(e.size||0)}</span><span class="file-detail">${FileManager.formatDate(e.lastModified)}</span>`;
      } else {
        el.innerHTML = `<span class="file-icon">${icon}</span> ${e.name}`;
      }
      el.addEventListener('click', (ev) => {
        if (ev.ctrlKey || ev.metaKey) { el.classList.toggle('selected'); return; }
        openFileEntry(e);
      });
      el.addEventListener('contextmenu', (ev) => { ev.preventDefault(); showFileContextMenu(ev, e); });
      container.appendChild(el);
    }
  });
}

// ═══════ FILE OPERATIONS ═══════
DOM.btnOpenFolder.addEventListener('click', openFolder);
DOM.btnOpenFolderC?.addEventListener('click', openFolder);
DOM.btnRefreshTree.addEventListener('click', refreshTree);

async function openFolder() {
  try {
    const r = await FileManager.openFolder(); if (!r) return;
    State.fileTree = r.entries; renderFileTree(r.entries, DOM.fileTree);
    toast('Opened folder', 'success');
  } catch (e) { toast(`Error: ${e.message}`, 'error'); }
}
async function refreshTree() {
  try {
    const e = await FileManager.refreshTree(); if (!e) return;
    State.fileTree = e; renderFileTree(e, DOM.fileTree);
  } catch (e) { toast(`Error: ${e.message}`, 'error'); }
}
async function openFileEntry(entry) {
  try {
    const text = await FileManager.readFile(entry);
    State.chunks = ChunkEngine.parseFileToChunks(text);
    State.currentFile = entry; State.modified = false;
    DOM.currentFilename.textContent = entry.path; DOM.saveStatus.textContent = '';
    document.querySelectorAll('.file-tree-file').forEach(el => el.classList.toggle('active', el.dataset.path === entry.path));
    renderAllChunks(); updatePreview(); updateInspector();
    toast(`Opened ${entry.name}`, 'info');
  } catch (e) { toast(`Error: ${e.message}`, 'error'); }
}

async function getUniqueName(dirH, baseName) {
  let name = baseName;
  let counter = 1;
  const existing = new Set();
  for await (const [n] of dirH.entries()) existing.add(n);
  
  while (existing.has(name)) {
    name = `${baseName} ${counter}`;
    counter++;
  }
  return name;
}

// New File / New Folder
async function createNewFile(entry) {
  let dirH = FileManager.getDirHandle();
  if (entry && entry.isDir) dirH = entry.handle;
  else if (entry && !entry.isDir) dirH = entry.dirHandle;

  if (!dirH) { toast('Open a folder first — click Open Folder', 'warn'); return; }
  
  try {
    const name = await getUniqueName(dirH, 'NewFile');
    const newEntry = await FileManager.createNewFile(name, dirH);
    
    // Set up app state
    const initContent = `# ${name}\n\n`;
    State.chunks = ChunkEngine.parseFileToChunks(initContent);
    State.currentFile = newEntry; State.modified = false;
    DOM.currentFilename.textContent = name;
    await refreshTree(); renderAllChunks(); updatePreview();
    toast(`Created ${name}`, 'success');
  } catch (err) { toast(`Error creating file: ${err.message}`, 'error'); }
}

async function createNewFolder(entry) {
  let dirH = FileManager.getDirHandle();
  if (entry && entry.isDir) dirH = entry.handle;
  else if (entry && !entry.isDir) dirH = entry.dirHandle;

  if (!dirH) { toast('Open a folder first — click Open Folder', 'warn'); return; }
  
  try {
    const name = await getUniqueName(dirH, 'NewFolder');
    await FileManager.createFolder(name, dirH);
    await refreshTree(); toast(`Created folder "${name}"`, 'success');
  } catch (err) { toast(`Error creating folder: ${err.message}`, 'error'); }
}

// Save
async function saveCurrentFile() {
  if (!State.currentFile) { toast('No file open', 'warn'); return; }
  try {
    // Save as clean raw markdown — no chunk delimiters, just the content + AI outputs
    const rawContent = ChunkEngine.chunksToCleanFile(State.chunks);
    await FileManager.writeHandle(State.currentFile.handle, rawContent);
    State.modified = false; DOM.saveStatus.textContent = '✓ Saved';
    document.querySelectorAll('.file-tree-file.modified').forEach(el => el.classList.remove('modified'));
    setTimeout(() => DOM.saveStatus.textContent = '', 2000);
    toast('Saved', 'success');
  } catch (e) { toast(`Save failed: ${e.message}`, 'error'); }
}
DOM.btnSave.addEventListener('click', saveCurrentFile);

function markModified() {
  if (State.modified) return;
  State.modified = true; DOM.saveStatus.textContent = '● Unsaved';
  if (State.currentFile) {
    const el = document.querySelector(`.file-tree-file[data-path="${State.currentFile.path}"]`);
    el?.classList.add('modified');
  }
}

// ═══════ FILE CONTEXT MENU ═══════
let _fileCtxEntry = null;
function showFileContextMenu(e, entry) {
  _fileCtxEntry = entry;
  
  const ctxOnly = DOM.fileContextMenu.querySelector('.ctx-file-only');
  if (ctxOnly) ctxOnly.style.display = entry ? 'block' : 'none';

  DOM.fileContextMenu.classList.remove('hidden');
  DOM.fileContextMenu.style.left = `${Math.min(e.clientX, innerWidth-180)}px`;
  DOM.fileContextMenu.style.top = `${Math.min(e.clientY, innerHeight-250)}px`;
}
function closeFileContextMenu() { DOM.fileContextMenu.classList.add('hidden'); _fileCtxEntry = null; }

// Right-click empty area of left panel
DOM.fileTree.addEventListener('contextmenu', e => {
  if (!e.target.closest('.file-tree-file') && !e.target.closest('.file-tree-folder')) {
    e.preventDefault();
    closeContextMenu();
    showFileContextMenu(e, null); // Show only New File/Folder
  }
});

document.addEventListener('click', e => {
  if (!DOM.fileContextMenu.contains(e.target)) closeFileContextMenu();
  if (!DOM.contextMenu.contains(e.target)) closeContextMenu();
});

let _deleteCallback = null;
DOM.fileContextMenu.querySelectorAll('button[data-action]').forEach(btn => {
  btn.addEventListener('click', async () => {
    const entry = _fileCtxEntry; closeFileContextMenu();
    const action = btn.dataset.action;
    
    try {
      if (action === 'new-file') return await createNewFile(entry);
      if (action === 'new-folder') return await createNewFolder(entry);
      
      if (action === 'paste-file') {
        if (!window._clipboard_entry) { toast('Clipboard is empty', 'warn'); return; }
        const targetHandle = entry ? (entry.isDir ? entry.handle : entry.dirHandle) : FileManager.getDirHandle();
        if (!targetHandle) { toast('Cannot determine destination', 'error'); return; }
        try {
          if (window._clipboard_entry.op === 'copy') {
            await FileManager.copyFile(window._clipboard_entry.entry, targetHandle);
            toast('File pasted', 'success');
          } else {
            await FileManager.moveFile(window._clipboard_entry.entry, targetHandle);
            toast('File moved', 'success');
            window._clipboard_entry = null;
          }
          await refreshTree();
        } catch(e) { toast('Paste error: ' + e.message, 'error'); }
        return;
      }

      if (!entry) return; // actions below need an entry
      
      switch (action) {
        case 'open-file': openFileEntry(entry); break;
        case 'rename-file': showRenameModal(entry); break;
        case 'copy-file':
          toast('Select destination folder and click Paste.', 'info');
          window._clipboard_entry = { op: 'copy', entry };
          break;
        case 'move-file':
          toast('Select destination folder and click Paste.', 'info');
          window._clipboard_entry = { op: 'move', entry };
          break;
        case 'duplicate-file':
          await FileManager.duplicateFile(entry); await refreshTree();
          toast(`Duplicated ${entry.name}`, 'success'); break;
        case 'download-file':
          await FileManager.downloadFile(entry); toast('Downloading…', 'info'); break;
        case 'delete-file': showDeleteConfirm(entry); break;
      }
    } catch (e) { toast(`Error: ${e.message}`, 'error'); }
  });
});

// Delete confirm modal
function showDeleteConfirm(entry) {
  DOM.deleteConfirmMsg.textContent = `Delete "${entry.name}"? This cannot be undone.`;
  DOM.modalDeleteConfirm.classList.remove('hidden');
  _deleteCallback = async () => {
    try {
      if (entry.isDir) await FileManager.deleteFolder(entry.dirHandle, entry.name);
      else await FileManager.deleteFile(entry.dirHandle, entry.name);
      await refreshTree(); toast(`Deleted ${entry.name}`, 'success');
    } catch (e) { toast(`Error: ${e.message}`, 'error'); }
  };
}
DOM.deleteCancel.addEventListener('click', () => { DOM.modalDeleteConfirm.classList.add('hidden'); _deleteCallback = null; });
DOM.deleteConfirm.addEventListener('click', () => { DOM.modalDeleteConfirm.classList.add('hidden'); _deleteCallback?.(); _deleteCallback = null; });

// Rename modal
let _renameEntry = null;
function showRenameModal(entry) {
  _renameEntry = entry;
  DOM.renameInput.value = entry.name;
  DOM.modalRename.classList.remove('hidden');
  setTimeout(() => DOM.renameInput.focus(), 50);
}
DOM.renameCancel.addEventListener('click', () => { DOM.modalRename.classList.add('hidden'); _renameEntry = null; });
DOM.renameConfirm.addEventListener('click', async () => {
  const newName = DOM.renameInput.value.trim();
  if (!newName || !_renameEntry) return;
  try {
    if (_renameEntry.isDir) {
      await FileManager.renameFolder(_renameEntry, newName);
    } else {
      await FileManager.renameFile(_renameEntry, newName);
    }
    await refreshTree(); toast(`Renamed to ${newName}`, 'success');
  } catch (e) { toast(`Error: ${e.message}`, 'error'); }
  DOM.modalRename.classList.add('hidden'); _renameEntry = null;
});

// ═══════ KEYBOARD SHORTCUTS ═══════
document.addEventListener('keydown', e => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key === 's') { e.preventDefault(); saveCurrentFile(); }
  if (mod && e.key === 'o') { e.preventDefault(); openFolder(); }
  if (mod && e.key === 'b') { e.preventDefault(); Formatting.exec('bold'); }
  if (mod && e.key === 'i') { e.preventDefault(); Formatting.exec('italic'); }
  if (mod && e.key === 'u') { e.preventDefault(); Formatting.exec('underline'); }
  if (mod && e.key === 'h') { e.preventDefault(); DOM.frPanel.classList.toggle('hidden'); DOM.frFindInput.focus(); }
  if (mod && e.key === 'z' && !e.shiftKey) { e.preventDefault(); doUndo(); }
  if (mod && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) { e.preventDefault(); doRedo(); }
  if (e.key === 'Escape') {
    closeContextMenu(); closeFileContextMenu();
    DOM.modalChunkType.classList.add('hidden');
    DOM.modalDeleteConfirm.classList.add('hidden');
    DOM.modalRename.classList.add('hidden');
    DOM.frPanel.classList.add('hidden');
    DOM.aiDrawer.classList.add('hidden');
  }
});

// ═══════ NOTEBOOK TOOLBAR ═══════
DOM.btnAddChunkTop.addEventListener('click', () => showAddChunkModal(null));
DOM.btnCollapseAll.addEventListener('click', () => { State.chunks = State.chunks.map(c => ({...c, collapsed:true})); renderAllChunks(); });
DOM.btnExpandAll.addEventListener('click', () => { State.chunks = State.chunks.map(c => ({...c, collapsed:false})); renderAllChunks(); });
DOM.btnRunAll.addEventListener('click', async () => {
  if (!State.chunks.length) { toast('No cells to run', 'warn'); return; }
  for (const c of State.chunks) {
    if (c.type === 'ai-prompt' || c.type === 'code') {
      await runChunk(c.id);
      // Wait 600ms between calls to avoid API rate limits
      await new Promise(r => setTimeout(r, 600));
    }
  }
});

// ═══════ CHUNK TYPE MODAL ═══════
let _modalInsertAfterId = null, _selectedType = null;
function showAddChunkModal(afterId) {
  _modalInsertAfterId = afterId; _selectedType = null;
  DOM.modalLangSelector.classList.add('hidden'); DOM.modalConfirm.disabled = true;
  document.querySelectorAll('.chunk-type-card').forEach(c => c.classList.remove('selected'));
  DOM.modalChunkType.classList.remove('hidden');
}
document.querySelectorAll('.chunk-type-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.chunk-type-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected'); _selectedType = card.dataset.type;
    DOM.modalLangSelector.classList.toggle('hidden', _selectedType !== 'code');
    DOM.modalConfirm.disabled = false;
  });
});
DOM.modalCancel.addEventListener('click', () => DOM.modalChunkType.classList.add('hidden'));
DOM.modalChunkType.addEventListener('click', e => { if (e.target === DOM.modalChunkType) DOM.modalChunkType.classList.add('hidden'); });
DOM.modalConfirm.addEventListener('click', () => {
  if (!_selectedType) return;
  addChunk(_modalInsertAfterId, _selectedType, _selectedType === 'code' ? DOM.modalLangSelect.value : '');
  DOM.modalChunkType.classList.add('hidden');
});

function addChunk(afterId, type, lang) {
  const r = afterId == null ? ChunkEngine.insertChunkFirst(State.chunks, type, lang) : ChunkEngine.insertChunkAfter(State.chunks, afterId, type, lang);
  State.chunks = r.chunks; renderAllChunks(); updatePreview(); updateInspector(); markModified();
  setTimeout(() => { document.querySelector(`.chunk-cell[data-id="${r.newId}"] .chunk-editor`)?.focus(); }, 80);
}

// ═══════ RENDER CHUNKS ═══════
function renderAllChunks() {
  const c = DOM.chunksContainer;
  if (!State.chunks.length) { c.innerHTML = ''; c.appendChild(DOM.emptyNotebook); return; }
  if (DOM.emptyNotebook.parentElement === c) DOM.emptyNotebook.remove();
  c.innerHTML = '';
  c.appendChild(makeAddStrip(null));
  State.chunks.forEach((chunk, idx) => { c.appendChild(makeChunkCell(chunk, idx)); c.appendChild(makeAddStrip(chunk.id)); });
}

function makeAddStrip(afterId) {
  const s = document.createElement('div'); s.className = 'add-chunk-strip';
  const b = document.createElement('button'); b.className = 'add-chunk-btn'; b.textContent = '+ Add Cell';
  b.addEventListener('click', () => showAddChunkModal(afterId)); s.appendChild(b); return s;
}

function makeChunkCell(chunk, idx) {
  const cell = document.createElement('div');
  cell.className = `chunk-cell type-${chunk.type}`; cell.dataset.id = chunk.id; cell.draggable = true;

  // Header
  const header = document.createElement('div'); header.className = 'chunk-header';
  const drag = document.createElement('span'); drag.className = 'chunk-drag-handle'; drag.textContent = '⠿'; drag.title = 'Drag to reorder';
  const badge = document.createElement('span'); badge.className = 'chunk-type-badge';
  badge.textContent = chunk.type === 'ai-prompt' ? 'AI Prompt' : chunk.type;
  const idLabel = document.createElement('span'); idLabel.className = 'chunk-id-label'; idLabel.textContent = `#${idx+1}`;
  header.appendChild(drag); header.appendChild(badge);

  if (chunk.type === 'code') {
    const langs = ['javascript','typescript','python','bash','rust','go','sql','text','html','css','json','yaml'];
    const sel = document.createElement('select'); sel.className = 'chunk-lang-select';
    langs.forEach(l => { const o = document.createElement('option'); o.value = l; o.textContent = l; if (l===chunk.lang) o.selected = true; sel.appendChild(o); });
    sel.addEventListener('change', () => { State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, {lang:sel.value}); markModified(); });
    header.appendChild(sel);
  }
  header.appendChild(idLabel);
  const spacer = document.createElement('span'); spacer.className = 'chunk-header-spacer'; header.appendChild(spacer);

  const mkBtn = (icon, title, cls, fn) => { const b = document.createElement('button'); b.className = `chunk-action-btn ${cls}`; b.innerHTML = icon; b.title = title; b.addEventListener('click', fn); return b; };
  // ALL cell types get a Run button — sends content to Ollama
  header.appendChild(mkBtn('▶','Run cell — send to Ollama (Ctrl+Enter)','run-btn',() => runChunk(chunk.id)));
  header.appendChild(mkBtn(chunk.collapsed?'⊞':'⊟','Toggle','collapse-btn',() => { State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, {collapsed:!chunk.collapsed}); renderAllChunks(); }));
  header.appendChild(mkBtn('⋮','More','ctx-btn', e => { e.stopPropagation(); showContextMenu(e, chunk.id); }));
  header.appendChild(mkBtn('🗑','Delete','del-btn',() => deleteChunk(chunk.id)));

  // Body
  const body = document.createElement('div'); body.className = `chunk-body${chunk.collapsed?' collapsed':''}`;
  const editor = document.createElement('textarea'); editor.className = 'chunk-editor';
  editor.value = chunk.content;
  editor.placeholder = chunk.type === 'markdown' ? 'Write markdown… Ctrl+Enter to send to AI' : chunk.type === 'code' ? '// Code here… Ctrl+Enter to send to AI' : 'Ask AI… Ctrl+Enter to run';
  editor.spellcheck = chunk.type === 'markdown';

  const debouncedSaveUndo = debounce(() => UndoManager.push(chunk.id, chunk.content), 800);
  editor.addEventListener('input', () => {
    debouncedSaveUndo();
    State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, {content:editor.value});
    autoResize(editor); markModified(); debouncedPreview(); debouncedInspector();
  });
  editor.addEventListener('keydown', e => {
    if ((e.ctrlKey||e.metaKey) && e.key === 'Enter') { e.preventDefault(); runChunk(chunk.id); }
    if (e.key === 'Tab') { e.preventDefault(); const s = editor.selectionStart; editor.value = editor.value.slice(0,s)+'  '+editor.value.slice(editor.selectionEnd); editor.selectionStart = editor.selectionEnd = s+2; State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, {content:editor.value}); }
  });
  editor.addEventListener('focus', () => {
    cell.classList.add('focused');
    State._focusedChunkId = chunk.id;
    Formatting.setActiveEditor(editor);
  });
  // Delay removing .focused so toolbar mousedown events can still find the editor
  editor.addEventListener('blur', () => {
    setTimeout(() => {
      // Only remove if a different editor got focus or no editor has focus
      if (document.activeElement !== editor && !document.activeElement?.classList?.contains('chunk-editor')) {
        cell.classList.remove('focused');
      }
    }, 150);
  });
  body.appendChild(editor); setTimeout(() => autoResize(editor), 10);

  // Output
  const hasOut = chunk.output?.trim();
  const outEl = document.createElement('div'); outEl.className = `chunk-output${hasOut?'':' hidden'}`;
  const outH = document.createElement('div'); outH.className = 'chunk-output-header'; outH.innerHTML = '<span class="output-type-badge">Output</span>';
  
  const rightBtns = document.createElement('div');
  rightBtns.style.marginLeft = 'auto'; rightBtns.style.display = 'flex'; rightBtns.style.gap = '8px';
  const copyBtn = document.createElement('button'); copyBtn.className = 'output-clear-btn'; copyBtn.textContent = '📋 Copy';
  copyBtn.addEventListener('click', () => { window.ClipboardUtils.copy(chunk.output||'').then(() => toast('Copied output to clipboard', 'success')).catch(() => toast('Failed to copy. Try selecting and copying manually.', 'error')); });
  
  const clrBtn = document.createElement('button'); clrBtn.className = 'output-clear-btn'; clrBtn.textContent = '✕ Clear';
  clrBtn.addEventListener('click', () => { State.chunks = ChunkEngine.updateChunk(State.chunks, chunk.id, {output:''}); outEl.classList.add('hidden'); outC.textContent = ''; markModified(); updatePreview(); });
  
  rightBtns.appendChild(copyBtn); rightBtns.appendChild(clrBtn);
  outH.appendChild(rightBtns);
  const outC = document.createElement('div'); outC.className = `chunk-output-content${chunk.type==='ai-prompt'?' rendered':''}`;
  if (hasOut) { outC[chunk.type==='ai-prompt'?'innerHTML':'textContent'] = chunk.type==='ai-prompt' ? PreviewEngine.renderToHtml(chunk.output) : chunk.output; }
  outEl.appendChild(outH); outEl.appendChild(outC); body.appendChild(outEl);
  cell.appendChild(header); cell.appendChild(body);
  setupDragHandlers(cell, drag);
  return cell;
}

function autoResize(ta) { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 600) + 'px'; }

// ═══════ RUN CHUNK (all types → Ollama/OpenAI REST API) ═══════
async function runChunk(chunkId) {
  const chunk = State.chunks.find(c => c.id === chunkId); if (!chunk) return;
  if (!chunk.content.trim()) { toast('Cell is empty — write something first', 'warn'); return; }
  const cell = document.querySelector(`.chunk-cell[data-id="${chunkId}"]`);
  const outEl = cell?.querySelector('.chunk-output'), outBody = cell?.querySelector('.chunk-output-content');
  updateAiClient();
  const prior = State.chunks.slice(0, State.chunks.findIndex(c => c.id === chunkId));
  if (State.runController) State.runController.abort();
  State.runController = new AbortController();
  cell?.classList.add('running'); outEl?.classList.remove('hidden');
  if (outBody) { outBody.textContent = ''; outBody.classList.add('streaming'); outBody.classList.add('rendered'); }
  let acc = '';
  try {
    await OllamaClient.runChunk(chunk, prior, token => {
      acc += token;
      // Always render output as rich markdown HTML
      if (outBody) { outBody.innerHTML = PreviewEngine.renderToHtml(acc); outBody.scrollTop = outBody.scrollHeight; }
    }, State.runController.signal);
    State.chunks = ChunkEngine.updateChunk(State.chunks, chunkId, {output:acc}); markModified(); updatePreview(); toast('Done ✓','success');
  } catch (e) {
    if (e.name === 'AbortError') toast('Cancelled','warn');
    else { toast(`Error: ${e.message}`,'error'); if (outBody) outBody.textContent = `Error: ${e.message}`; }
  } finally { cell?.classList.remove('running'); outBody?.classList.remove('streaming'); State.runController = null; }
}

function deleteChunk(id) { State.chunks = ChunkEngine.removeChunk(State.chunks, id); renderAllChunks(); updatePreview(); updateInspector(); markModified(); }

// ═══════ CHUNK CONTEXT MENU ═══════
let _ctxChunkId = null;
function showContextMenu(e, id) { _ctxChunkId = id; DOM.contextMenu.classList.remove('hidden'); DOM.contextMenu.style.left = `${Math.min(e.clientX,innerWidth-170)}px`; DOM.contextMenu.style.top = `${Math.min(e.clientY,innerHeight-180)}px`; }
function closeContextMenu() { DOM.contextMenu.classList.add('hidden'); _ctxChunkId = null; }

DOM.contextMenu.querySelectorAll('button[data-action]').forEach(btn => {
  btn.addEventListener('click', () => {
    if (!_ctxChunkId) return; const id = _ctxChunkId;
    switch (btn.dataset.action) {
      case 'move-up': State.chunks = ChunkEngine.moveChunk(State.chunks, id, 'up'); break;
      case 'move-down': State.chunks = ChunkEngine.moveChunk(State.chunks, id, 'down'); break;
      case 'duplicate': State.chunks = ChunkEngine.duplicateChunk(State.chunks, id); break;
      case 'delete': State.chunks = ChunkEngine.removeChunk(State.chunks, id); break;
    }
    closeContextMenu(); renderAllChunks(); updatePreview(); updateInspector(); markModified();
  });
});

// ═══════ DRAG & DROP ═══════
let _dragId = null;
function setupDragHandlers(cell, handle) {
  const id = cell.dataset.id;
  handle.addEventListener('mousedown', () => cell.draggable = true);
  cell.addEventListener('dragstart', e => { _dragId = id; e.dataTransfer.effectAllowed = 'move'; setTimeout(() => cell.classList.add('dragging'), 0); });
  cell.addEventListener('dragend', () => { cell.classList.remove('dragging'); document.querySelectorAll('.drag-over-top,.drag-over-bottom').forEach(el => el.classList.remove('drag-over-top','drag-over-bottom')); });
  cell.addEventListener('dragover', e => { e.preventDefault(); if (_dragId===id) return; const mid = cell.getBoundingClientRect().top + cell.offsetHeight/2; cell.classList.toggle('drag-over-top',e.clientY<mid); cell.classList.toggle('drag-over-bottom',e.clientY>=mid); });
  cell.addEventListener('dragleave', () => cell.classList.remove('drag-over-top','drag-over-bottom'));
  cell.addEventListener('drop', e => {
    e.preventDefault(); if (!_dragId || _dragId===id) return;
    cell.classList.remove('drag-over-top','drag-over-bottom');
    const before = e.clientY < cell.getBoundingClientRect().top + cell.offsetHeight/2;
    const fi = State.chunks.findIndex(c => c.id === _dragId), ti = State.chunks.findIndex(c => c.id === id);
    if (fi<0||ti<0) return;
    const arr = [...State.chunks]; const [m] = arr.splice(fi,1);
    const ins = before ? (fi<ti?ti-1:ti) : (fi<ti?ti:ti+1);
    arr.splice(Math.max(0,ins), 0, m);
    State.chunks = arr; renderAllChunks(); updatePreview(); updateInspector(); markModified(); _dragId = null;
  });
}

// ═══════ LIVE UPDATES ═══════
function updatePreview() { PreviewEngine.updatePreview(State.chunks, DOM.previewHtml, DOM.previewTextarea); }
const debouncedPreview = debounce(updatePreview, 300);
function updateInspector() {
  const a = VariableInspector.analyzeAll(State.chunks);
  const rl = (ul, items) => { ul.innerHTML = ''; if (!items.length) { ul.innerHTML = '<li class="empty-hint">—</li>'; return; } items.forEach(i => { const li = document.createElement('li'); li.innerHTML = `${i.name}<span class="var-chunk">cell ${i.chunkIdx+1}</span>`; ul.appendChild(li); }); };
  rl(DOM.inspectorGlobals, a.globals); rl(DOM.inspectorFunctions, a.functions); rl(DOM.inspectorVars, a.variables);
}
const debouncedInspector = debounce(updateInspector, 500);

// ═══════ PANEL RESIZE ═══════
function setupGutter(gId, pId, dir) {
  const g = document.getElementById(gId), p = document.getElementById(pId);
  if (!g||!p) return; let sx, sw;
  g.addEventListener('mousedown', e => {
    sx = e.clientX; sw = p.offsetWidth; g.classList.add('dragging');
    document.body.style.cursor = 'col-resize'; document.body.style.userSelect = 'none';
    const mv = e => { const d = dir==='left'?e.clientX-sx:sx-e.clientX; p.style.width = `${Math.max(180,Math.min(600,sw+d))}px`; };
    const up = () => { g.classList.remove('dragging'); document.body.style.cursor=''; document.body.style.userSelect=''; document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up); };
    document.addEventListener('mousemove',mv); document.addEventListener('mouseup',up);
  });
}
setupGutter('gutter-l','left-panel','left'); setupGutter('gutter-r','right-panel','right');

renderAllChunks();
