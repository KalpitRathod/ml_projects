/**
 * features.js
 * Word processing formatting, find & replace, AI settings drawer,
 * file context menu, undo/redo, autocorrect.
 */

// ═══════════════════════════════════════
// CLIPBOARD FALLBACK
// ═══════════════════════════════════════
window.ClipboardUtils = (() => {
  async function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch (err) {
        console.warn('Clipboard API failed, trying fallback...');
      }
    }
    return new Promise((resolve, reject) => {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      try {
        const res = document.execCommand('copy');
        document.body.removeChild(ta);
        if (res) resolve(true);
        else reject(new Error('ExecCommand failed'));
      } catch (err) {
        document.body.removeChild(ta);
        reject(err);
      }
    });
  }

  async function read() {
    if (navigator.clipboard && navigator.clipboard.readText) {
      return navigator.clipboard.readText();
    }
    throw new Error('Paste not supported in this context. Use Ctrl+V.');
  }

  return { copy, read };
})();

// ═══════════════════════════════════════
// UNDO / REDO STACK (per chunk)
// ═══════════════════════════════════════
const UndoManager = (() => {
  const _stacks = {};  // chunkId → { undo: [], redo: [] }
  const MAX = 50;

  function _get(id) {
    if (!_stacks[id]) _stacks[id] = { undo: [], redo: [] };
    return _stacks[id];
  }

  function push(id, content) {
    const s = _get(id);
    s.undo.push(content);
    if (s.undo.length > MAX) s.undo.shift();
    s.redo = [];
  }

  function undo(id, currentContent) {
    const s = _get(id);
    if (!s.undo.length) return null;
    s.redo.push(currentContent);
    return s.undo.pop();
  }

  function redo(id, currentContent) {
    const s = _get(id);
    if (!s.redo.length) return null;
    s.undo.push(currentContent);
    return s.redo.pop();
  }

  function clear(id) { delete _stacks[id]; }
  function canUndo(id) { return !!(_stacks[id]?.undo.length); }
  function canRedo(id) { return !!(_stacks[id]?.redo.length); }

  return { push, undo, redo, clear, canUndo, canRedo };
})();

// ═══════════════════════════════════════
// AUTOCORRECT
// ═══════════════════════════════════════
const AutoCorrect = (() => {
  const DICT = {
    'teh':'the','adn':'and','taht':'that','wiht':'with','hte':'the',
    'dont':'don\'t','cant':'can\'t','wont':'won\'t','didnt':'didn\'t',
    'im':'I\'m','ive':'I\'ve','youre':'you\'re',
    'recieve':'receive','occured':'occurred','seperate':'separate',
    'definately':'definitely','accomodate':'accommodate','occurence':'occurrence',
  };

  function correct(text) {
    return text.replace(/\b(\w+)\b/g, (match) => {
      const lower = match.toLowerCase();
      return DICT[lower] || match;
    });
  }

  function correctLastWord(text) {
    const match = text.match(/(\S+)\s$/);
    if (!match) return text;
    const word = match[1].toLowerCase();
    if (DICT[word]) {
      return text.slice(0, text.length - match[0].length) + DICT[word] + ' ';
    }
    return text;
  }

  return { correct, correctLastWord, DICT };
})();

// ═══════════════════════════════════════
// FORMATTING COMMANDS
// ═══════════════════════════════════════
const Formatting = (() => {

  // Stores the last-focused editor so toolbar clicks work even after blur
  let _lastEditor = null;

  /** Set the last focused editor (called from app.js on focus) */
  function setActiveEditor(editorEl) {
    _lastEditor = editorEl;
  }

  /** Get the last active chunk editor textarea */
  function _activeEditor() {
    // Try live focused element first, then fall back to stored ref
    const focused = document.querySelector('.chunk-cell.focused .chunk-editor');
    return focused || _lastEditor;
  }

  /** Wrap selected text with prefix/suffix in the active editor */
  function wrapSelection(prefix, suffix) {
    const ed = _activeEditor();
    if (!ed) return;
    const start = ed.selectionStart;
    const end   = ed.selectionEnd;
    const sel   = ed.value.substring(start, end);
    const wrapped = prefix + (sel || 'text') + (suffix || prefix);
    ed.value = ed.value.slice(0, start) + wrapped + ed.value.slice(end);
    ed.selectionStart = start + prefix.length;
    ed.selectionEnd   = start + prefix.length + (sel || 'text').length;
    ed.focus();
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  /** Insert text at cursor in acive editor */
  function insertAtCursor(text) {
    const ed = _activeEditor();
    if (!ed) return;
    const pos = ed.selectionStart;
    ed.value = ed.value.slice(0, pos) + text + ed.value.slice(ed.selectionEnd);
    ed.selectionStart = ed.selectionEnd = pos + text.length;
    ed.focus();
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  /** Prepend prefix to each selected line */
  function prependLines(prefix) {
    const ed = _activeEditor();
    if (!ed) return;
    const start = ed.selectionStart;
    const end   = ed.selectionEnd;
    const lineStart = ed.value.lastIndexOf('\n', start - 1) + 1;
    const lineEnd   = ed.value.indexOf('\n', end);
    const block = ed.value.substring(lineStart, lineEnd === -1 ? undefined : lineEnd);
    const newBlock = block.split('\n').map(line => prefix + line).join('\n');
    ed.value = ed.value.slice(0, lineStart) + newBlock + ed.value.slice(lineEnd === -1 ? ed.value.length : lineEnd);
    ed.focus();
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  const COMMANDS = {
    'bold':          () => wrapSelection('**', '**'),
    'italic':        () => wrapSelection('*', '*'),
    'underline':     () => wrapSelection('<u>', '</u>'),
    'strikethrough': () => wrapSelection('~~', '~~'),
    'code-inline':   () => wrapSelection('`', '`'),
    'link':          () => { const url = prompt('URL:','https://'); if(url) wrapSelection('[', `](${url})`); },
    'image':         () => { const url = prompt('Image URL:','https://'); if(url) insertAtCursor(`![alt](${url})`); },
    'hr':            () => insertAtCursor('\n\n---\n\n'),
    'blockquote':    () => prependLines('> '),
    'code-block':    () => insertAtCursor('\n```\n\n```\n'),
    'bullet-list':   () => prependLines('- '),
    'numbered-list': () => {
      const ed = _activeEditor();
      if (!ed) return;
      const start = ed.selectionStart;
      const end   = ed.selectionEnd;
      const lineStart = ed.value.lastIndexOf('\n', start - 1) + 1;
      const lineEnd   = ed.value.indexOf('\n', end);
      const block = ed.value.substring(lineStart, lineEnd === -1 ? undefined : lineEnd);
      let n = 1;
      const newBlock = block.split('\n').map(line => `${n++}. ${line}`).join('\n');
      ed.value = ed.value.slice(0, lineStart) + newBlock + ed.value.slice(lineEnd === -1 ? ed.value.length : lineEnd);
      ed.focus();
      ed.dispatchEvent(new Event('input', { bubbles: true }));
    },
    'checklist':     () => prependLines('- [ ] '),
    'align-left':    () => insertAtCursor('\n<!-- align:left -->\n'),
    'align-center':  () => insertAtCursor('\n<!-- align:center -->\n'),
    'align-right':   () => insertAtCursor('\n<!-- align:right -->\n'),
    'table':         () => insertAtCursor('\n| Header 1 | Header 2 | Header 3 |\n|----------|----------|----------|\n| Cell 1   | Cell 2   | Cell 3   |\n'),
    'cut':           () => {
      const ed = _activeEditor();
      if (!ed) return;
      const start = ed.selectionStart, end = ed.selectionEnd;
      if (start === end) return;
      const sel = ed.value.substring(start, end);
      window.ClipboardUtils.copy(sel).then(() => {
        ed.value = ed.value.slice(0, start) + ed.value.slice(end);
        ed.selectionStart = ed.selectionEnd = start;
        ed.dispatchEvent(new Event('input', { bubbles: true }));
      }).catch(() => {});
    },
    'copy':          () => {
      const ed = _activeEditor();
      if (!ed) return;
      const sel = ed.value.substring(ed.selectionStart, ed.selectionEnd);
      if (sel) window.ClipboardUtils.copy(sel).catch(() => {});
    },
    'paste':         () => window.ClipboardUtils.read().then(t => insertAtCursor(t)).catch(e => {
      console.warn(e);
      if (typeof toast !== 'undefined') toast('Please use Ctrl+V to paste', 'warn');
    }),
  };

  function exec(cmd) {
    if (COMMANDS[cmd]) COMMANDS[cmd]();
  }

  return { exec, wrapSelection, insertAtCursor, prependLines, setActiveEditor };
})();

// ═══════════════════════════════════════
// FIND & REPLACE
// ═══════════════════════════════════════
const FindReplace = (() => {
  let _matches = [];
  let _current = -1;

  function find(query) {
    _matches = [];
    _current = -1;
    if (!query) return { total: 0, current: 0 };

    const editors = document.querySelectorAll('.chunk-editor');
    editors.forEach(ed => {
      const text = ed.value;
      const lower = text.toLowerCase();
      const q = query.toLowerCase();
      let idx = 0;
      while ((idx = lower.indexOf(q, idx)) !== -1) {
        _matches.push({ editor: ed, start: idx, end: idx + query.length });
        idx += query.length;
      }
    });

    if (_matches.length > 0) _current = 0;
    return { total: _matches.length, current: _current + 1 };
  }

  function next() {
    if (!_matches.length) return null;
    _current = (_current + 1) % _matches.length;
    _scrollTo(_matches[_current]);
    return { total: _matches.length, current: _current + 1 };
  }

  function prev() {
    if (!_matches.length) return null;
    _current = (_current - 1 + _matches.length) % _matches.length;
    _scrollTo(_matches[_current]);
    return { total: _matches.length, current: _current + 1 };
  }

  function replaceCurrent(replacement) {
    if (_current < 0 || !_matches.length) return;
    const m  = _matches[_current];
    const ed = m.editor;
    ed.value = ed.value.slice(0, m.start) + replacement + ed.value.slice(m.end);
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function replaceAll(query, replacement) {
    const editors = document.querySelectorAll('.chunk-editor');
    let count = 0;
    editors.forEach(ed => {
      const re = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      const before = ed.value;
      ed.value = ed.value.replace(re, replacement);
      if (before !== ed.value) { count++; ed.dispatchEvent(new Event('input', { bubbles: true })); }
    });
    _matches = [];
    _current = -1;
    return count;
  }

  function _scrollTo(m) {
    if (!m) return;
    m.editor.focus();
    m.editor.selectionStart = m.start;
    m.editor.selectionEnd   = m.end;
    // Scroll the chunk cell into view
    const cell = m.editor.closest('.chunk-cell');
    if (cell) cell.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  return { find, next, prev, replaceCurrent, replaceAll };
})();

// ═══════════════════════════════════════
// SYSTEM PROMPT PRESETS
// ═══════════════════════════════════════
const PromptPresets = {
  general: 'You are a helpful AI assistant embedded in a Markdown notebook editor. Provide clear, concise, and accurate responses.',
  coder: 'You are an expert code assistant. Focus on writing clean, efficient, well-documented code. Explain your reasoning. Always format code in proper markdown code blocks with the correct language tag.',
  writer: 'You are a skilled writing assistant. Focus on grammar, clarity, prose quality, and engaging writing style. Help the user improve their text and suggest better phrasing.',
  tutor: 'You are a patient and thorough tutor. Explain concepts step-by-step, use analogies and examples. Check for understanding. Break complex topics into digestible parts.',
  custom: '',
};
